const About = () => <h2>About Us</h2>;

export default About;
