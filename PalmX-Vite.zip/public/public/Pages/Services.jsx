const Services = () => <h2>Services</h2>;

export default Services;
